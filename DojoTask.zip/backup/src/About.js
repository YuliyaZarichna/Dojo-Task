import React from 'react';

class About extends React.Component {
    render() {
        return(
            <div>About me</div>
        )
    }
}

export default About;
